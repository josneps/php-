<?php

namespace Home\Model;

use Think\Model;
use think\Db;

/**
 * Class ClassName
 * @package Home\Model
 */
class AnswerModel extends Model
{
    protected $tableName = 'designer_answer';


}