<?php

namespace Home\Model;

use Think\Model;
use think\Db;

/**
 * Class ClassName
 * @package Home\Model
 */
class IntegralModel extends Model
{
    protected $tableName = 'designer_integral';

    /**
     * @todo: 积分列表
     * @author： friker
     * User: Administrator
     * Date: 2019/8/13
     * Time: 15:35
     */
    public function getList()
    {

    }
}