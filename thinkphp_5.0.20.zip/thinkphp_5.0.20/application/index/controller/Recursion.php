<?php

namespace app\index\controller;

use think\Controller;

use app\index\service\recursionService;

/**
 * 
 */
class Recursion extends Controller
{
    //定义一个受保护的属性
    protected $recursionService;
    
    //构造方法
    public function __construct(recursionService $recursionService)
    {
        parent::__construct();
        $this->recursionService = $recursionService;
    }

    public function index()
    {
        // $recursionService = new recursionService();

        $data = $this->recursionService->getList();

        // print_r($data);
        // 
        $this->assign('data', $data);

        return $this->fetch();

    }

}

