<?php
//000000000000
 exit();?>
a:5:{i:0;s:3:"404";i:1;s:25:"admin/LoginController/err";i:2;s:3:"404";i:3;a:0:{}i:4;a:0:{}}