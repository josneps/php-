<?php
//000000000000
 exit();?>
a:5:{i:0;s:11:"index/index";i:1;s:17:"admin/Index/index";i:2;s:11:"index|index";i:3;a:0:{}i:4;a:0:{}}