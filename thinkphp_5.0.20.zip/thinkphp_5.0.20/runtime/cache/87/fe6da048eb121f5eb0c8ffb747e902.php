<?php
//000000000000
 exit();?>
a:5:{i:0;s:11:"admin/login";i:1;s:27:"admin/LoginController/login";i:2;s:17:"admin|login|index";i:3;a:0:{}i:4;a:0:{}}