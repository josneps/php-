<?php
//000000000000
 exit();?>
a:5:{i:0;s:10:"actr/index";i:1;s:29:"admin/ArticleController/index";i:2;s:10:"actr|index";i:3;a:0:{}i:4;a:0:{}}