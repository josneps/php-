<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:73:"F:\project\php-\thinkphp_5.0.20\public/../application/admin\view\404.html";i:1564314700;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>404</title>
	<style type="text/css">
		body {
			background-color: yellow;
		}

		div {
			text-align: center;
			font-size: 100px;
			width: 450px;
			height: 400px;
			position: absolute;
			top: 50%;
			left: 50%;
			margin-left: -175px;
			margin-top: -200px;
			color: red;
		}
	</style>
</head>
<body>
	<div>
		404 <br>
		出错了，兄嘚儿…
	</div>
</body>
</html>