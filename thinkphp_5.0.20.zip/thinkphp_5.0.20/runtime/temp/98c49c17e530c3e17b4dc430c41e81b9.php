<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:94:"F:\project\php-\thinkphp_5.0.20\public/../application/admin\view\article_controller\index.html";i:1565024128;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	23333
</body>
</html>