<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:86:"F:\project\php-\thinkphp_5.0.20\public/../application/index\view\recursion\upload.html";i:1565194819;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>文件上传</title>
</head>
<body>
	<form action="" method="post" enctype="multipart/form-data">
		<input type="file" name="file"> <br>
		<input type="submit" value="上传">
	</form>
	<div>
		<a href="/404">首页</a>
	</div>
	<div>
		<a href="<?php echo url('index/index/list'); ?>">中奖</a>
	</div>
	<div>
		<a href="<?php echo url('index/happy/happy'); ?>">快乐</a>
	</div>
	<div>
		<a href="<?php echo url('index/motion/motion'); ?>">运动</a>
	</div>
</body>
</html>