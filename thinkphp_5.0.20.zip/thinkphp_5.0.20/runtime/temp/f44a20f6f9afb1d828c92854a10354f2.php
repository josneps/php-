<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:85:"F:\project\php-\thinkphp_5.0.20\public/../application/index\view\recursion\index.html";i:1564822187;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>无限极分类</title>
</head>
<body>
    <table>
        <tr>
            <td>服装：</td>
        </tr>
        <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$item): $mod = ($i % 2 );++$i;?>
        <tr>
            <td><?php  echo str_repeat('--',$item['f'])  ?><?php echo $item['name']; ?></td>
        </tr>
        <?php endforeach; endif; else: echo "" ;endif; ?>
    </table>
</body>
</html>