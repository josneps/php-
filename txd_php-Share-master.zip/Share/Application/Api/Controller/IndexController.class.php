<?php
/**
 * Created by PhpStorm.
 * User: ľ
 * Date: 2018/8/13
 * Time: 9:21
 */
namespace Api\Controller;
class IndexController extends BaseController
{
    public function index() {
        echo 'Hello World!';
    }


}