<?php
/**
 * Created by PhpStorm.
 * User: 木公子
 * Date: 2018/7/23
 * Time: 10:55
 */
return array(
    //'配置项'=>'配置值'
    'DB_TYPE'   => 'Mysql', // 数据库类型
    'DB_HOST'   => '101.201.252.128', // 服务器地址
    'DB_NAME'   => 'share', // 数据库名
    'DB_USER'   => 'share', // 用户名
    'DB_PWD'    => 'share0941',  // 密码
    'DB_PORT'   => '3306', // 端口
    'DB_PREFIX' => 'db_', // 数据库表前缀
//
//    'DB_TYPE'   => 'Mysql', // 数据库类型
//    'DB_HOST'   => '127.0.0.1', // 服务器地址
//    'DB_NAME'   => 'share', // 数据库名
//    'DB_USER'   => 'root', // 用户名
//    'DB_PWD'    => 'root',  // 密码
//    'DB_PORT'   => '3306', // 端口
//    'DB_PREFIX' => 'db_', // 数据库表前缀
);