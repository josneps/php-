<?php
/**
 * Created by PhpStorm.
 * User: ľ
 * Date: 2018/8/16
 * Time: 11:48
 */

namespace Common\Model;


use Common\Service\ModelService;

class FileModel extends ModelService
{

}