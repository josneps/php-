<?php

namespace Common\Model;

/**
 * 三方绑定表
 * Class MemberBindModel
 * @package Common\Model
 */

use Common\Service\ModelService;
class MemberBindModel extends ModelService{


}