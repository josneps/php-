<?php
/**
 * Created by PhpStorm.
 * User: Txunda
 * Date: 2018/7/24
 * Time: 16:10
 */

namespace Home\Controller;


use Common\Service\ControllerService;

class BaseController extends ControllerService
{
    public function _initialize()
    {
        parent::_initialize();
    }
}