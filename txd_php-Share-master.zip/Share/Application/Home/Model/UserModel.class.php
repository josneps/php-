<?php
/**
 * Created by PhpStorm.
 * User: 木公子
 * Date: 2018/7/23
 * Time: 10:53
 */

namespace Home\Model;


use Common\Service\ModelService;

class UserModel extends ModelService
{


}