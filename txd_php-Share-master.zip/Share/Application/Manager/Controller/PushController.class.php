<?php
/**
 * Created by PhpStorm.
 * User: 权限控制自动生成 By admin
 * Date: 2018-08-15
 * Time: 13:20:28
 */

namespace Manager\Controller;


class PushController extends BaseController
{


    /**
     * 推送记录
     * User: admin
     * Date: 2018-08-15 13:20:28
     */
    public function index() {

    }

    /**
     * 推送记录
     * User: admin
     * Date: 2018-08-15 16:29:41
     */
    public function index() {

    }
}