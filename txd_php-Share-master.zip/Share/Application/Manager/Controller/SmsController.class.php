<?php
/**
 * Created by PhpStorm.
 * User: 权限控制自动生成 By admin
 * Date: 2018-08-15
 * Time: 13:19:35
 */

namespace Manager\Controller;


class SmsController extends BaseController
{


    /**
     * 短信管理
     * User: admin
     * Date: 2018-08-15 13:19:35
     */
    public function index() {

    }

    /**
     * 发信记录
     * User: admin
     * Date: 2018-08-15 16:29:26
     */
    public function index() {

    }
}