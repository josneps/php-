<?php
/**
 * Created by PhpStorm.
 * User: 权限控制自动生成 By admin
 * Date: 2018-08-16
 * Time: 13:38:06
 */

namespace Manager\Controller;


class UserController extends BaseController
{


    /**
     * ceshi
     * User: admin
     * Date: 2018-08-16 13:38:27
     */
    public function addUser() {
        $this->display();
    }
}