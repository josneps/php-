<?php
/**
 * Created by PhpStorm.
 * User: ľ
 * Date: 2018/8/14
 * Time: 14:48
 */

namespace Manager\Model;


use Common\Service\ModelService;

class AdminBehaviorModel extends ModelService
{

}