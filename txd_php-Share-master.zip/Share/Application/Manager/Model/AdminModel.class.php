<?php
/**
 * Created by PhpStorm.
 * User: 木
 * Date: 2018/8/3
 * Time: 15:08
 */

namespace Manager\Model;


use Common\Service\ModelService;

class AdminModel extends ModelService
{

}