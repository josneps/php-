<?php
namespace Manager\Model;

use Common\Service\ModelService;

/**
 * Class WebModel
 * @package Manager\Model
 * 汇总记录
 * 2018/05/13 上午10:40
 */
class AdvertModel extends ModelService {


    /**
     * @var array
     * 自动验证   使用create()方法时自动调用
     */
    protected $_validate = array();
    /**
     * @var array
     * 自动完成   新增时
     */
    protected $_auto = array ();




}