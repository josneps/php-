<?php
/**
 * Created by PhpStorm.
 * User: ľ
 * Date: 2018/8/14
 * Time: 14:47
 */

namespace Manager\Model;


use Common\Service\ModelService;

class ConfigModel extends ModelService
{

}