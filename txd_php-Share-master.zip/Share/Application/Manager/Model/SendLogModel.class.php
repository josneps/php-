<?php
/**
 * Created by PhpStorm.
 * User: ?
 * Date: 2018/8/14
 * Time: 14:47
 */

namespace Manager\Model;


use Common\Service\ModelService;

class SendLogModel extends ModelService
{

}